#ifndef CONFIG_H
#define CONFIG_H

#define HOST_ADDRESS "127.0.0.1"
#define HOST_PORT    9000

#endif // CONFIG_H
