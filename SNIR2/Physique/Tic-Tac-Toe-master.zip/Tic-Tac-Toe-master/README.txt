README.txt

Description:
A tcp client-server tic-tac-toe game written in C++ and Qt.

Future Features:
* Separate client-server processes and projects
* Add game metrics
* Add unit tests
* Custom widget buttons (nicer layouts)
* Draw win line when done
